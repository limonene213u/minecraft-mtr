MTR NTE 1067mm rail pack readme

YouTube: https://www.youtube.com/@soodari6791

This pack require Minecraft Transit Railway Mod (Fabric 1.19.2~)made by jonafanho
and Nemo's Transit Expansion
Mod Link(MTR): https://www.curseforge.com/minecraft/mc-mods/minecraft-transit-railway
Mod Link(NTE): https://modrinth.com/mod/mtr-nte/

[Model parts developers]
* Original Rail models are made by Huli
* Original Rail can be found at Nemo's Transit Expansion.

Terms and Conditions
1. This resource pack can be added in private or public MTR mod server.
2. Using this resource pack and the components of the model pack is deemed to be your own responsibility for everything involved.
3. We are not responsible for any problems with this model pack.