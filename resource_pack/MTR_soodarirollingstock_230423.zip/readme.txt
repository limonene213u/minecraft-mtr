MTR SoodariRollingsTock Resource Pack readme

Download link: https://1drv.ms/u/s!AjKCzO3McuvRhTW-SErJaIsoWceN?e=wfQDkK
YouTube: https://www.youtube.com/@soodari6791

This pack require Minecraft Transit Railway Mod (Fabric 1.19.2~)made by jonafanho
Mod Link: https://www.curseforge.com/minecraft/mc-mods/minecraft-transit-railway

* Original Train Models made by Jonathan
* Dual_side LRV Trains made by Europa the Silkwing/PKMNSWSH

Terms and Conditions
1. This resource pack can be modified without permission (Freely), please include(credit) my nickname(Soodari)
when you proceed with the second creation using this resource pack.
2. Using this resource pack and the components of the model pack is deemed to be your own responsibility for everything involved.
3. We are not responsible for any problems with this model pack.
4. Do not Redistribute this pack privately. Please Share the original Download link.
5. This resource pack can be added in private or public MTR mod server.


Trains (Repainted Korean, Australian and The Netherlands trains are included.)
K_Train with seoul metro 2000, 3000 livery
K_Train with seoul metro 5000, 9000 livery
Class 802 with KTX_EUM livery
DB BR 423 with GTX livery
Class 802 with Electric Tilt Train livery
Class 802 with NS Intercity livery
M_Train with Transperth livery
M_Train with QR IMU120 livery
M_Train with Amsterdam M5 livery
A_Train with New Generation Rollingstock livery
Dual_side LRV With Amsterdam M1 livery
DB BR 423 with NS Sprinter livery
Class 377 with MAXX livery
Class 377 with Tron Express livery
A_Train with AT Metro livery

